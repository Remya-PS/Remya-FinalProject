package org.capgemini.controller;
import java.util.Map;
import javax.validation.Valid;

import org.capgemini.pojo.Wishlist;
import org.capgemini.service.WishlistService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WishListController {
	
	
	
	@Autowired

	
	public WishlistService wishlistservice;
	public Wishlist wishlist12;
	

	
	@RequestMapping("/wishlist")
	public String showWishlist(Map<String, Object> map){
		
				map.put( "wishlist12", new Wishlist());
			
				
				
		System.out.println("Show");
				//map.put("accounts", accountService.getAllAccounts());
				
				
				return "jspwishpage";
				//return "accountRegister";
	}


		
		
		
		@RequestMapping(value="/savewishlist",method=RequestMethod.POST)  
		public void savewishlist(@Valid @ModelAttribute("wishlist12") Wishlist wishlist,
				BindingResult result){
			
			if(!result.hasErrors()){
				System.out.println(wishlist12);
				wishlistservice.saveWishlist(wishlist12);
				
			
		}
			//return savewishlist(wishlist12, result)();
		

		}
}
		
		
	

	
	
	
	
	

