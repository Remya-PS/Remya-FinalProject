package org.capgemini.service;

import org.capgemini.pojo.Wishlist;

public interface WishlistService {
	
	
	public void saveWishlist(Wishlist wishlist);

}
