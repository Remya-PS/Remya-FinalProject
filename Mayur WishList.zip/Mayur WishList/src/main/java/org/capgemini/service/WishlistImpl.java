package org.capgemini.service;

import org.capgemini.dao.WishlistDao;


import org.capgemini.pojo.Wishlist;

public class WishlistImpl implements WishlistService {

	@Override
	public void saveWishlist(Wishlist wishlist) {
		
		
		WishlistImpl wish1=new WishlistImpl();
		
		wish1.saveWishlist(wishlist);

		
	}

}
