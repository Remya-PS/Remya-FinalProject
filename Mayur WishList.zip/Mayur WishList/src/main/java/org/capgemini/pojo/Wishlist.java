package org.capgemini.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Wishlist")


public class Wishlist {
	
	
	public int product_list;
	
	public int customer_id;
	
	
	/// no argument constructor
	public Wishlist(){}
	
	
		@Id
	    @Column(name = "product_list")
	    @GeneratedValue
	// generating getters and setters
	public int getProduct_list() {
		return product_list;
	}

	public void setProduct_list(int product_list) {
		this.product_list = product_list;
	}

	
		@Id
	    @Column(name = "customer_id")
	    @GeneratedValue
	
	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	
	// adding to string method
	@Override
	public String toString() {
		return "Wishlist [product_list=" + product_list + ", customer_id=" + customer_id + "]";
	}

	public Wishlist(int product_list, int customer_id) {
		super();
		this.product_list = product_list;
		this.customer_id = customer_id;
	}



}
