package org.capgemini.pojo;

import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		AnnotationConfiguration config=new AnnotationConfiguration();
		
		
		config.addAnnotatedClass(Wishlist.class);
		config.configure();
		
		
		//Re-create the schema EveryTime
				
		new SchemaExport(config).create(true, true);
		
		
		
		
		
	}

}
