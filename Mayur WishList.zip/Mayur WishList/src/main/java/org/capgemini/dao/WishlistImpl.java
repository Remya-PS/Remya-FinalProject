package org.capgemini.dao;

import org.capgemini.pojo.Wishlist;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class WishlistImpl implements WishlistDao {

	

	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	public void saveWishlist(Wishlist wishlist) {
		
		sessionFactory.getCurrentSession().save(wishlist);
	
		


		
	}

}
