package org.capgemini.dao;


import org.capgemini.pojo.Wishlist;

public interface WishlistDao {

	
	public void saveWishlist(Wishlist wishlist);
	
}


//wishlist.saveWishlist(wishlist);

//public void saveEmployee(Employee employee);