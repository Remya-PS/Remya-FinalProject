function isValidData(){
	
	var flag=true;
	
	//validate if customer id is null or empty or exists
	var custumer_id=addCartForm.cId.value;
	//var custumer_id=document.getElementById("cId").value;
	if (custumer_id == null || custumer_id == ""||!isValidCustomerId()) {
	       document.getElementById("customer_id_val").innerHTML="*Please enter Valid Customer Id!";
	        flag=false;
	    }else
	    	document.getElementById("customer_id_val").innerHTML="";
	
		
	//validate if product id is null or empty or exists
	//var product_id=document.getElementById("pId").value;
	var product_id=addCartForm.pId.value;
		if(product_id==null||product_id==""||!isValidProductId()){
			document.getElementById("productId_val").innerHTML="*Please enter valid Product Id!";
	        flag=false;
	    }else
	    	document.getElementById("productId_val").innerHTML="";
		
		
		//validate if product name is null or empty or of required pattern
		//var product_name=document.getElementById("pName").value;
		var product_name=addCartForm.pName.value;
		if(product_name==null||product_name==""||!isValidProductName()){
			document.getElementById("productName_val").innerHTML="*Please enter valid Product Name!";
	        flag=false;
	    }else
	    	document.getElementById("productName_val").innerHTML="";
		
		
		//validate if quantity is null or empty or of required range
		var quantity=addCartForm.quan.value;
		if(quantity==null||quantity==""||!isValidQuantity()){
			
			document.getElementById("quantity_val").innerHTML="*Quantity should be between 1 and 5";
			flag = false;
		}
			
		else
			document.getElementById("quantity_val").innerHTML="";
		
		
		
		return flag;
	}
	
//validating if customer id exists
function isValidCustomerId(){
	var custumer_id=addCartForm.cId.value;
	
	if(custumer_id>0 && custumer_id<=3)
		return true;
	else
		return false;
}

//validating if product id exists
function isValidProductId(){
	var product_id=addCartForm.pId.value;
	
	if(product_id>0 && product_id<=3)
		return true;
	else
		return false;
}

//validating if product name exists
function isValidProductName(){
	
	var pattern=/[A-Za-z0-9@., ]+$/;
	
	if(document.getElementById("pName").value.match(pattern))	
		return true;
	else
		return false;
}

//validating if quantity is within the range
function isValidQuantity(){
	var quantity=addCartForm.quan.value;
	
	if(product_id>0 && product_id<=5)
		return true;
	else
		return false;
}