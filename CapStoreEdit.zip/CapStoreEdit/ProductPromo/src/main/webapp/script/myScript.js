var app=angular.module('cartApp',[]);

app.controller("ctrl",function($scope,$http){
	$http.get('http://localhost:8010/ManagingCart/cart').
    success(function(data){
		$scope.cart=data;
	});
	
	
});



