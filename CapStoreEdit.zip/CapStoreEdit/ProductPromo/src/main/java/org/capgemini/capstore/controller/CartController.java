package org.capgemini.capstore.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.validation.Valid;

import org.capgemini.capstore.domain.Cart;
import org.capgemini.capstore.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.http.HttpStatus;

@Controller
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	//method to show the add item to cart form
	@RequestMapping("/cartForm")
	public String showCartForm(Map<String, Object> maps)
	{
		maps.put("car", new Cart());
		return "CartForm";
	}
	
	//method to save the items to cart
	@RequestMapping(value="/saveCart",method=RequestMethod.POST)
	public String showCartDetails(Map<String, Object> map,
			@Valid @ModelAttribute("car") Cart cart,
			BindingResult result)
	{
		
		cartService.saveCart(cart);
		return "redirect:/cartForm";
		
}
	//method to get all items in cart
	@RequestMapping(value="/cart",method=RequestMethod.GET,
	produces={"application/json"})
	public @ResponseBody List<Cart> getAllDepartments(){
		
		
		List<Cart> cart=cartService.getAllCart();
		System.out.println("car="+cart);
		
		return cart;
	}
	
	//method to display all items as json object
	@RequestMapping(value="/car",method=RequestMethod.GET,
	produces={"application/json"})
	public  String getPromoNames()
	{
	
	return "showCart";
	}
	

//deleting product from the cart
@RequestMapping("/deleteProduct/{productId}")
public String deleteEmployee(@PathVariable("productId") Integer productId){
	cartService.deleteProduct(productId);
	return "redirect:/car";
}


}
