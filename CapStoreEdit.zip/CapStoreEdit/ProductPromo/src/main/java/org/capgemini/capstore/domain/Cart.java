package org.capgemini.capstore.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;
//Cart table
@Entity
public class Cart {
	
	//fields to enter to cart table
	@Id
	@GeneratedValue
	private int serial_no;
	
	@NotNull(message="Customer ID should be given")
	private int customer_id;
	@NotNull(message="Product ID should be entered ")
	private int productId;
	
	@NotNull(message="Product Name should be entered ")
	private String productName;
	
	@Range(min=1,max=5,message="*Number of quantity should be between 1 and 5")
	private int quantity;

	//No-argument constructor
	public Cart() {
		super();
	}

	//Full field Constructor
	public Cart(int serial_no, int customer_id, int productId, String productName, int quantity) {
		super();
		this.serial_no = serial_no;
		this.customer_id = customer_id;
		this.productId = productId;
		this.productName = productName;
		this.quantity = quantity;
	}

	//Getters and setters
	public int getSerial_no() {
		return serial_no;
	}


	public void setSerial_no(int serial_no) {
		this.serial_no = serial_no;
	}


	public int getCustomer_id() {
		return customer_id;
	}


	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	//hashcode 
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + customer_id;
		result = prime * result + productId;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + quantity;
		result = prime * result + serial_no;
		return result;
	}

	//Equals method overridden
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cart other = (Cart) obj;
		if (customer_id != other.customer_id)
			return false;
		if (productId != other.productId)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (quantity != other.quantity)
			return false;
		if (serial_no != other.serial_no)
			return false;
		return true;
	}

	//To-String method
	@Override
	public String toString() {
		return "Cart [serial_no=" + serial_no + ", customer_id=" + customer_id + ", productId=" + productId
				+ ", productName=" + productName + ", quantity=" + quantity + "]";
	}


	
	
}
