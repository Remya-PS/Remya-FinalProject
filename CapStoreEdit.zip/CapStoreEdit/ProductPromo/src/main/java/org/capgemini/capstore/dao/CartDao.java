package org.capgemini.capstore.dao;

import java.util.List;
import java.util.Objects;

import org.capgemini.capstore.domain.Cart;
// cart Dao interface
public interface CartDao {

	public void saveCart(Cart cart);
	public List<Cart> getAllCart();
	public void deleteProduct(Integer productId);
	
}
