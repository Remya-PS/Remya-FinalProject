package org.capgemini.capstore.service;

import java.util.List;
import java.util.Objects;

import org.capgemini.capstore.dao.CartDao;
import org.capgemini.capstore.domain.Cart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//Cart Service Interface Implementation
@Service
public class CartServiceImplementation implements CartService{
	
	@Autowired
	private CartDao cartDao;

	//method to save to cart
	@Override
	@Transactional
	public void saveCart(Cart cart) {
	
		cartDao.saveCart(cart);
	}

	//method to get all items in cart
	@Override
	@Transactional
	public List<Cart> getAllCart() {
		return cartDao.getAllCart();
	}

	
	//method to delete product from the cart
	@Override
	@Transactional
	public void deleteProduct(Integer productId) {
		cartDao.deleteProduct(productId);
	}

}
