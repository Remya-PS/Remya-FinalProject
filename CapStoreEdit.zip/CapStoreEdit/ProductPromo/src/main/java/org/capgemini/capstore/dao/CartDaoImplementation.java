package org.capgemini.capstore.dao;

import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpSession;

import org.capgemini.capstore.domain.Cart;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaQuery;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class CartDaoImplementation implements CartDao{
	
	//HttpSession session=request.getSession(false);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	//method to save items to cart
	@Override
	public void saveCart(Cart cart) {
		sessionFactory.getCurrentSession().save(cart);
		
	}

	//method to get all items from the cart
	@Override
	public List<Cart> getAllCart() {
		return sessionFactory.getCurrentSession().createQuery("from Cart").list();
	}

	//method to delete product from the cart
	@Override
	public void deleteProduct(Integer productId) {
		Cart cart=(Cart) sessionFactory.getCurrentSession().get(Cart.class, productId);
		if(cart!=null)
			sessionFactory.getCurrentSession().delete(cart);
		
	}


	
	}
	 
	



