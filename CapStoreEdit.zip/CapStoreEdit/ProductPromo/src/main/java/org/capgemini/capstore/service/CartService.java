package org.capgemini.capstore.service;

import java.util.List;
import java.util.Objects;

import org.capgemini.capstore.domain.Cart;
//Cart Service Interface
public interface CartService {
	public void saveCart(Cart cart);
	public List<Cart> getAllCart();
	public void deleteProduct(Integer productId);
	
}
