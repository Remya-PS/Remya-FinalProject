package org.capgemini.capstore.test;

public class DaoTest {

}
