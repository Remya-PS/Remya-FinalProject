package org.capgemini.demo;

public class Y implements InterA{

	@Override
	public void show() {
		System.out.println("Y class Method");
		
	}

}
