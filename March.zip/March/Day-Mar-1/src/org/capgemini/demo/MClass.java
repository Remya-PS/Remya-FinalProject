package org.capgemini.demo;

public class MClass<T extends InterA> {
	
	private T obj;
	 
	public MClass(T obj){
		this.obj=obj;
	}
	
	public void printClass(){
		System.out.println(obj.getClass().getName());
		obj.show();
	}
	
}
