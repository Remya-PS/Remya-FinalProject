package org.capgemini.demo;

public class MainClass {

	public static void main(String[] args) {
		Circle<Character,String> circle=new Circle<Character,String>('D',"Tom");
		
		circle.showInfo();

	}

}
