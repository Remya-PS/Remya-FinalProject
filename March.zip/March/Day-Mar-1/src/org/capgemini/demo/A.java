package org.capgemini.demo;

public class A {
	
	public void show(){
		System.out.println("A class Method");
	}

}
