package org.capgemini;

public class MainClass {

	public static void main(String[] args) {
		//Person customer=new Person();
		Person customer=new Customer();
		//Customer customer=new Customer(1,"Jerry",1200,"90132132312");
		customer.show();
	}

}
