package org.capgemini.demo;

public class MainClass {

	public static void main(String[] args) {
		
		System.out.println("ThreadNAme = " + Thread.currentThread().getName());
		
		ThreadDemo t1=new ThreadDemo("FirstThread");
		ThreadDemo t2=new ThreadDemo("SecondThread");
		
		t1.start();
		
		t2.start();
		

	}

}
