package org.capgemini.demo;

public class Main {

	public static void main(String[] args) {
		
		PrintString p1=new PrintString("Capgemini");
		PrintString p2=new PrintString("Welcome");

		
		Thread t1=new Thread(p1,"First");
		Thread t2=new Thread(p2,"second");
		
		/*t1.start();
		t1.start();
		*/
		
		t1.run();
		t2.start();
	}

}
