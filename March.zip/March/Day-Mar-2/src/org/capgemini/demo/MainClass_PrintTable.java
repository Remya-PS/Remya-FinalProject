package org.capgemini.demo;

public class MainClass_PrintTable {

	public static void main(String[] args) {
		MyThread table1=new MyThread(10);
		MyThread table2=new MyThread(13);
		MyThread table3=new MyThread(19);
		MyThread table4=new MyThread(12);

		
		Thread t1=new Thread(table1);
		Thread t2=new Thread(table2);
		Thread t3=new Thread(table3);
		Thread t4=new Thread(table4);
		
		
		t1.start();
		
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		t2.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		t3.start();
		t4.start();
		
		
	}

}
