package org.capgemini;

public class Example {
	static int count;
	int num;
	
	static{
		System.out.println("Static Var:"+count);
		System.out.println("Static block");
	}

	
	{
		System.out.println("Normal block");
	}
	
	public Example(){
		System.out.println("Constructor");
	}
	
	public static void main(String[] args) {
		Example example=new Example();
		Example example1=new Example();
	}

}
