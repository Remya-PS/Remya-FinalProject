package org.capgemini;

import java.util.Scanner;

public class Student extends Person {
	
	int mark1,mark2,mark3;
	
	@Override
	public void show(){
		System.out.println("Student Class Show Method");
	}
	
	
	public static void myMethod(){
		System.out.println("Student Class Static Method");
		Person.myMethod();
	}
	
	
	public void getDetails(){
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Id:");
		personId=sc.nextInt();
		
		System.out.println("Enter Name:");
		personName=sc.next();
		
		System.out.println("Enter marks");
		mark1=sc.nextInt();
		mark2=sc.nextInt();
		mark3=sc.nextInt();
	}

	
	public void printDetails(){
		System.out.println("Id:" + personId + "\nName:" +personName +"\n"
				+ "Marks :" + mark1 +"," + mark2+"," + mark3);
	}
}
