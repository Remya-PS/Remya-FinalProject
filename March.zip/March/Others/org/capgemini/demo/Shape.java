package org.capgemini.demo;

public abstract class Shape {
	
	public abstract void draw();
	
	public void non_Abstract_Method(){
		System.out.println("Shape class non_Abstract_Method");
	}

}
