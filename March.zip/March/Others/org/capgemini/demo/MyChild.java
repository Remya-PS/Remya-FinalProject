package org.capgemini.demo;

public   class MyChild extends MyClass{
	
	String myName;
	
	public  MyChild() {
		System.out.println("No Arg Constructor-MyChild");
	}

	public MyChild(int count,String myName){
		super(count);
		System.out.println("Arg Constructor - MyChild");
		this.myName=myName;
		
	}
	
	public void print(){
		System.out.println("Count : " + count + "\nName:" + myName);
	}
	
	@Override
	public int calculate(int num1, int num2) {
		// TODO Auto-generated method stub
		return num1+num2;
	}

	

}
