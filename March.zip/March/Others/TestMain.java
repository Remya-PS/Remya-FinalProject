package org.capgemini.demo;

public class TestMain {

	public static void main(String[] args) {
		
		int[] myArr=null;
		
		SortArray array=new SortArray();
		
		myArr=array.getArrayElements(myArr);
		
		array.printArrayElements(myArr);
		
		
		
		System.out.println("Sorter Order");
		myArr=array.sortArray(myArr);
		array.printArrayElements(myArr);

	}

}
