package org.cap.bookstore;

import java.util.Scanner;

public class Book {
	private int bookId;
	private String bookName;
	private String author;
	private String publisher;
	private double price;
	
	
	public Book getBookDetails(){
		Book book=new Book();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter BookId:");
		book.bookId=sc.nextInt();
		
		System.out.println("Enter bookName:");
		book.bookName=sc.next();
		
		System.out.println("Enter Author:");
		book.author=sc.next();
		
		System.out.println("Enter Price:");
		book.price=sc.nextDouble();
		
		return book;
	}

	public void showBookDetails(){
		System.out.println(bookId+"\t"+bookName+"\t"+author+"\t"+price);
	}
	
}
