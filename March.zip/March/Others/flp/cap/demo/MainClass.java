package flp.cap.demo;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		Employee employee=null;
		int option;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("1.Weekly Salary");
		System.out.println("2.Monthly Salary");
		System.out.println("Enter Your Option:");
		option=sc.nextInt();
		
		if(option==1)
			employee=new WeeklySalaryEmployee();
		else if(option==2)
			employee=new MonthlySalaryEmployee();
		
		employee.getEmployee();
		double sal=employee.calculateSalary();
		employee.printEmployee();
		System.out.println("Salary:" + sal);
		

	}

}
