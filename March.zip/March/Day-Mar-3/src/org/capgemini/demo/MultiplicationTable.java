package org.capgemini.demo;

public class MultiplicationTable {
	
	/*private int num;
	
	public MultiplicationTable(int num){
		this.num=num;
	}
	*/
	
		
		
		/*synchronized (this) {
			for(int i=1;i<=20;i++)
				System.out.println(i+"*"+num+"="+(i*num));
			
		}
		*/
	
	
	
	public void printTable(int num){
		System.out.println(Thread.currentThread().getName() + "-Started");
		
		synchronized (this) {
			for(int i=1;i<=20;i++)
				System.out.println(i+"*"+num+"="+(i*num));
		}
		
		System.out.println(Thread.currentThread().getName() + "-Ended");
		
	}

}
