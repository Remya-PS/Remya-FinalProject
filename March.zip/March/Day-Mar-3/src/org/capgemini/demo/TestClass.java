package org.capgemini.demo;


public class TestClass {

	public static void main(String[] args) {
		/*
		MultiplicationTable t1=new MultiplicationTable(12);
		MultiplicationTable t2=new MultiplicationTable(13);
		MultiplicationTable t3=new MultiplicationTable(19);
		
		t1.start();
		t2.start();
		t3.start();*/
		
	
	

	}
	

}
