package org.capgemini.demo;

public class MyThread extends Thread{
	
	private int num;
	
	public void run(){
		
	}

}
