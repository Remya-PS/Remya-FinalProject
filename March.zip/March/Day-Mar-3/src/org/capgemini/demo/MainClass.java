package org.capgemini.demo;

public class MainClass {

	public static void main(String[] args) {
		
		ThreadGroup tgrp1=new ThreadGroup("report-thread");
		/*Thread dthread=new Thread(tgrp1,"DeamonThread"){
			
			@Override
			public void run(){
				for(int i=0;i<1000000;i++)
					System.out.println(Thread.currentThread().getName() + "-" + i);
			}
		};
		dthread.setDaemon(true);
		dthread.start();*/
	
		
		
		
		//Annonymous Class
		Runnable r1=new Runnable() {
			
			@Override
			public void run() {
				System.out.println(Thread.currentThread().getName()+" , Thread Priority="+Thread.currentThread().getPriority());
				for(int i=1;i<=15;i++)
					System.out.println(i+"*"+12+"="+(i*12));
			}
		};
		
		//Annonymous Class
				Runnable r2=new Runnable() {
					
					@Override
					public void run() {
						
						System.out.println(Thread.currentThread().getName()+" , Thread Priority="+Thread.currentThread().getPriority());
						for(int i=1;i<=15;i++)
							System.out.println(Thread.currentThread().getName()+"-->"+i+"*"+13+"="+(i*13));
					}
				};
		Thread t1=new Thread(tgrp1,r1);
		t1.setPriority(Thread.NORM_PRIORITY);
		t1.start();
		//t1.setPriority(10);
		//t1.setPriority(10);
		
		
		Thread.yield();
		
		Thread t2=new Thread(tgrp1,r2);
		t2.setPriority(1);
		t2.start();
		

		Thread t3=new Thread(r2);
		t3.start();
		
		
		
		
		
		
		
		
		Thread myThread=new Thread(tgrp1, r1);
		
		System.out.println("Active thread:" + tgrp1.activeCount());
		
		
		System.out.println("High Priority"+ tgrp1.getMaxPriority());
		


	}

}
