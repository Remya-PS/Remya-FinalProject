package org.capstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CartManagementController {

	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		return new ModelAndView("hello","message","Hello World!");
	}
}
