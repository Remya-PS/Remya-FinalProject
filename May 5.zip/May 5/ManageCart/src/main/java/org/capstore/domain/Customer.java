package org.capstore.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue
	private int customer_id;
	
	@NotEmpty(message="*Cart Id should be generated for each Customer")
	private int cart_id;
	
	@NotNull(message="*Customer Name is must")
	private String customer_name;
	
	
//--------------------------------------------POJO-----------------------------------------
	
	
	public Customer(){}


	public Customer(int cart_id, String customer_name) {
	super();
	this.cart_id = cart_id;
	this.customer_name = customer_name;
	
}


	public Customer(int customer_id, int cart_id, String customer_name, Cart cart, List<Product> product) {
		super();
		this.customer_id = customer_id;
		this.cart_id = cart_id;
		this.customer_name = customer_name;
		
	}

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public int getCart_id() {
		return cart_id;
	}

	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}


	@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", cart_id=" + cart_id + ", customer_name=" + customer_name
				+ "]";
	}

	
	

	
	
}

