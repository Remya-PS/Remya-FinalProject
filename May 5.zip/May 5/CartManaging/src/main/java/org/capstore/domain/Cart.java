package org.capstore.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "cart")
public class Cart {

		@Id
		@GeneratedValue
		private int serial_no;
		
		@NotEmpty(message="Product Name should be given")
		private int product_name;
		@NotEmpty(message="Cart Id should be given")
		private int cart_id;
		@NotEmpty(message="Atleast one item should be purchased")
		private int quantity;
		@NotEmpty(message="Product Price should be given")
		private double price;
		
		/// no argument constructor
		public Cart(){}

				
		public Cart(int serial_no, int product_name, int cart_id, int quantity, double price) {
			super();
			this.serial_no = serial_no;
			this.product_name = product_name;
			this.cart_id = cart_id;
			this.quantity = quantity;
			this.price = price;
		}



		public int getSerial_no() {
			return serial_no;
		}

		public void setSerial_no(int serial_no) {
			this.serial_no = serial_no;
		}

		public int getProduct_name() {
			return product_name;
		}

		public void setProduct_name(int product_name) {
			this.product_name = product_name;
		}

		public int getCart_id() {
			return cart_id;
		}

		public void setCart_id(int cart_id) {
			this.cart_id = cart_id;
		}

		public int getQuantity() {
			return quantity;
		}

		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}

		public double getPrice() {
			return price;
		}

		public void setPrice(double price) {
			this.price = price;
		}

		@Override
		public String toString() {
			return "Cart [serial_no=" + serial_no + ", product_name=" + product_name + ", cart_id=" + cart_id
					+ ", quantity=" + quantity + ", price=" + price + "]";
		}

		
		
		

}
