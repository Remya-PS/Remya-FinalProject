package org.capstore.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;


import org.capstore.domain.Cart;
import org.capstore.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;


	@Controller
	@RequestMapping("/carts")
	public class CartController {
		
		@Autowired
		private CartService cartService;
		private Cart searchCartItems=null;

		@RequestMapping("/empForm")
		public String showCartForm(Map<String, Object> maps){
						List<Cart> carts= cartService.getAllCartItems();
			maps.put("cart",carts);
			maps.put("cartSearch",searchCartItems);
			maps.put("cartList",new Cart());
			
			if(searchCartItems!=null){
			maps.put("cart", searchCartItems);
			
			
		}
			 return "cartDetails";
		}
		@RequestMapping(value={"/showCart","/updateCart"},method=RequestMethod.POST)
		public String showCartDetails(Map<String, Object> map,
				@Valid @ModelAttribute("cartList") Cart cartList, BindingResult result){
			List<Cart> carts= cartService.getAllCartItems();
			map.put("cart",carts);
			map.put("cartSearch",searchCartItems);
			if(result.hasErrors()){
				//System.out.println("Search Object:" + searchEmployee);
				//System.out.println(result);
				return "cartDetails";
			}
			else{
				searchCartItems=null;
				cartService.saveCartItems(cartList);
				return "redirect:/cartAddForm";
			}
		}
		
		
		
		@RequestMapping("/deleteCartItems/{product_name}")
		public String deleteCartItems(@PathVariable("product_name") Integer product_name){
			cartService.deleteCartItems(product_name);
			return "redirect:/cartAddForm";
		}
		
		@RequestMapping("/updateCart/{cart_id}")
		public String  updateCart(@PathVariable("cart_id") Integer cart_id){
			Cart cart=cartService.searchCartItems(cart_id);
			searchCartItems=cart;
			 //System.out.println(cart);
			return"redirect:/cartAddForm";
		}
}
