package org.capstore.dao;

import java.util.List;

import org.capstore.domain.Cart;
import org.capstore.domain.Customer;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class CartDaoImpl implements CartDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Transactional
	public void saveCartItems(Cart cart) {
		sessionFactory.getCurrentSession().save(cart);
		
		
	}
	
	@Transactional
	public List<Cart> getAllCartItems(Customer customer) {
		
		String sql="FROM Product where product_id In(Select product_id from cart where cart_id='"+customer.getCart_id()+"')";
		return sessionFactory.getCurrentSession().createQuery(sql).list();
	}
	@Transactional
	public void deleteCartItems(Integer product_id) {
		Cart cart=(Cart)sessionFactory.getCurrentSession().get(Cart.class, product_id);
		if(cart!=null)
			sessionFactory.getCurrentSession().delete(cart);
		
		
	}

	@Transactional
	public Cart searchCartItems(Integer product_id) {
		Cart cart=(Cart) sessionFactory.getCurrentSession().get(Cart.class, product_id);		
		return cart;
	}

		

}
