package flp.cap.demo;



public class Student {
	enum Gendar {
		MALE,FEMALE;
	}
	
	int studNo=1001;
	String studName="HEETHA";
	Gendar gendar=Gendar.FEMALE;

	
	
}

