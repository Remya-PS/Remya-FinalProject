package flp.cap.nestedclass;

public class TestClass {

	public static void main(String[] args) {
		
		/*OuterClass outerClass=new OuterClass();
		//outerClass.outerClsMethod();
		
		
		//Object created for inner Class
		OuterClass.InnerClass innerClass=outerClass.new InnerClass();
		innerClass.innerClsMethod();*/
		
		
		Shape triangle=new Shape() {
			
			@Override
			public void draw() {
				System.out.println("Draw Triangle");
				
			}
		};
		triangle.draw();
		
		Shape circle=new Shape() {
			
			@Override
			public void draw() {
				System.out.println("Draw circle");
				
			}
		};	
		
		circle.draw();

	}

}
