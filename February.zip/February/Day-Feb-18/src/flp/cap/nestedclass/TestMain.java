package flp.cap.nestedclass;

import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) {
		
		MyClass class1=new MyClass(){
			
			@Override
			public void show(){
				System.out.println("MyMethod in TestMain$1");
			}
		};
		
		class1.show();

		
		
		
		MyInterface interface1=new MyInterface() {
			
			@Override
			public void calculate() {
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter Number:");
				int num1=sc.nextInt();
				
				System.out.println("Enter Number:");
				int num2=sc.nextInt();
				
				System.out.println("Ans:" + (num1*num2));
				
			}
		};
		
		
		interface1.calculate();
		
		
		
		
		
		
		
		
	}

}
