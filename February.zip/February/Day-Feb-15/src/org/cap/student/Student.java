package org.cap.student;

import java.util.Scanner;

public class Student {
	private int studNo;
	private String firstName,lastName;
	private double fees;
	
	public void getStudentDetails(){
		Scanner sc=new  Scanner(System.in);
		System.out.println("Enter Stduent Id:");
		studNo=sc.nextInt();
		System.out.println("Enter Stduent firstName:");
		firstName=sc.next();
		
		System.out.println("Enter Stduent lastName:");
		lastName=sc.next();
		System.out.println("Enter Stduent Fees:");
		fees=sc.nextDouble();
		
	}
	
	public void printStudentDetails(){
		System.out.println( studNo + "\t" + firstName + 
				"\t" + lastName + "\t" + fees);
	}
	
	

}
