package org.capgemini.demo;

import java.util.Scanner;

public class SolveSeries {
	
	int num;
	double sum;
	
	public void getInput(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number:");
		num=sc.nextInt();
	}
	
	
	public double sumOfSeries(){
		
		for(int i=1;i<=num;i++)
			sum=sum+((double)findPower(i,i)/findFactorial(i));
		
		return sum;
		
	}


	private long findFactorial(int num) {
		
		long fact=1;
		
		for(int i=num;i>0;i--)
			fact=fact*i;
		
		return fact;
	}


	private long findPower(int base, int power) {
	
		long ans=1;
		for(int i=1;i<=power;i++)
			ans=ans*base;
		
		return ans;
	}
	
	
	
	
	
	
	

}
