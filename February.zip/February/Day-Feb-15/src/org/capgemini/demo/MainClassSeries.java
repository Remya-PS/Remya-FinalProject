package org.capgemini.demo;

public class MainClassSeries {

	public static void main(String[] args) {
		SolveSeries series=new SolveSeries();
		series.getInput();
		
		System.out.println("Sum Of Series:" + series.sumOfSeries());

	}

}
