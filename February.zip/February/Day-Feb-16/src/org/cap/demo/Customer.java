package org.cap.demo;

import java.util.Scanner;

public class Customer {
	
	private int custId;
	private String custName;
	private double regFees;
	private Address address;
	
	
	public Customer(){
		address=new Address();
	}
	
	public Customer(int custId,String custName,double regFees,Address address){
		this.custId=custId;
		this.custName=custName;
		this.regFees=regFees;
		this.address=address;
	}
	
	
	
	
	public void getCustomer(){
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Customer Id:");
		custId=scanner.nextInt();
		System.out.println("Enter Name:");
		custName=scanner.next();
		System.out.println("Enter Reg Fees:");
		regFees=scanner.nextDouble();
		
		//address=new Address();
		address.getAddress();
		
		
	}
	
	public void printCustomer(){
		System.out.println("Id:" + custId +"\nName:" + custName +"\nRegFees:" +
					regFees + "\nAddress:" + address.printAddress());
		//address.printAddress();
	}

	
	
}
