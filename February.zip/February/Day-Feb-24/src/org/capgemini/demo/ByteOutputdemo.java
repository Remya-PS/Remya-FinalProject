package org.capgemini.demo;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteOutputdemo {
	
	public static void main(String[] args){
		File file=new File("D:\\vidavid\\Training\\2016\\FLP_PUNE_8_FEB\\fileDemo\\byteiodemo.txt");
		
		String str="Good Morning! Have A Nice Day!";
		
		BufferedOutputStream bout=null;
		FileOutputStream fout=null;
		
		try{
			fout=new FileOutputStream(file);
			bout=new BufferedOutputStream(fout);
			
			byte[] myBytes=str.getBytes();
			
			
			bout.write(myBytes);
			
			
		}catch(FileNotFoundException ex){
			ex.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}finally {
			try{
			bout.close();
			fout.close();
			}catch(IOException e){
				e.printStackTrace();
			}
		}
		
		
	}

}
