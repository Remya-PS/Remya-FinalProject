package org.capgemini.demo;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CharReadDemo {

	public static void main(String[] args) {
		
		File file=new File("D:\\vidavid\\Training\\2016\\FLP_PUNE_8_FEB\\fileDemo\\myData.txt");
		FileReader fileReader=null;
		try {
			fileReader=new FileReader(file);
			
			long size=file.length();
			int len=(int)size;
			char[] chars=new char[len];
			
			int i=0;
			while(size>0){
				
				chars[i]=(char)fileReader.read();
				System.out.print(chars[i]);
				size--;
				i++;
			}
			
			System.out.println();
			
			for(int j=len-1;j>=0;j--){
				System.out.print(chars[j]);
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				fileReader.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		

	}

}
