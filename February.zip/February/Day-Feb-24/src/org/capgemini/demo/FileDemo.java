package org.capgemini.demo;

import java.io.File;
import java.io.IOException;
import java.util.Date;

public class FileDemo {

	public static void main(String[] args) {
		
		File file=new File("D:\\vidavid\\Training\\2016\\FLP_PUNE_8_FEB\\fileDemo\\myInfo.txt");
		if(file.exists()){
			if(file.isFile()){
				System.out.println("Size:" + file.length());
				System.out.println("LAst Modified:" + new Date(file.lastModified()));
				
				System.out.println("Is Readbale:" + file.canRead());
				System.out.println("Is Writable:" + file.canWrite());
			}else if(file.isDirectory()){
				String[] names=file.list();
				for(String str:names)
					System.out.println(str);
				
				System.out.println("Total Space:" + file.getTotalSpace());
				System.out.println("Free Space:" + file.getFreeSpace());
			}
		}
		else{
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("File does not exists");
		}
		
		
	}

}
