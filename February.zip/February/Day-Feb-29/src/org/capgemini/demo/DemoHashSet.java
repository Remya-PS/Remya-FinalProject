package org.capgemini.demo;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class DemoHashSet {

	public static void main(String[] args) {
		//Collection<Integer> lst=new HashSet<>();
		
		//Set<Integer> lst=new HashSet<>();
		HashSet<Integer> lst=new HashSet<>();
		
		lst.add(23);
		lst.add(23);lst.add(null);
		lst.add(2);
		lst.add(23);
		lst.add(120);lst.add(null);
		lst.add(15);
		lst.add(120);	lst.add(null);
		
		System.out.println(lst);
		
		/*
		//Enhanced For Loop
		for(Integer num:lst)
			System.out.println(num);
		
		*/
		Iterator<Integer> itr= lst.iterator();
		//while(itr.hasNext())
		
		
		itr.next();
		itr.next();
		itr.next();
		itr.next();
		
			System.out.println(itr.next());

	}

}
