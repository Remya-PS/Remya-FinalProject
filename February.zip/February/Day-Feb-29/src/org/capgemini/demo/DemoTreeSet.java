package org.capgemini.demo;

import java.util.TreeSet;

public class DemoTreeSet {

	public static void main(String[] args) {
		
		TreeSet<Integer> set=new TreeSet<>();
		set.add(23);
		set.add(230);
		//set.add(null);
		set.add(23);set.add(120);
		set.add(3);set.add(-2);set.add(23);
		set.add(2);set.add(23);set.add(120);
		//set.add(null);
		
		System.out.println(set);

	}

}
