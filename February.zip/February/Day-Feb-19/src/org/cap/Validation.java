package org.cap;

public class Validation {
	
	public static boolean isValidKinid(String kinId){
		return kinId.matches("\\d{5}_[F|I|T][S]");
	}
	
	public static boolean isValidName(String empName){
		return empName.matches("[A-Z][a-z]+");
	}

}
