package org.cap;

import java.util.Date;

public class DateDemo {

	public static void main(String[] args) {
		
		Date myDate=new Date();
		
		System.out.println(myDate);
		
		Date date=new Date(2001 - 1900, 11-1, 23, 12, 34);
		System.out.println(date);
		
		
		String str="12-jan-2000";
		Date date2=new Date();
		System.out.println(date2);
		
		
		System.out.println(date2.getTime());
		
		System.out.println(date2.getDate());
		
		System.out.println(date2.getMonth());
		System.out.println(date2.getYear());
		
		System.out.println(date2.getMinutes());
		System.out.println(date2.getSeconds());
		System.out.println(date2.getHours());
		
		Date date3=new Date();
		Date myDate1=new Date(2000, 11, 10);
		
		System.out.println(date3.before(myDate1));
		
		System.out.println(date2);
		date2.setDate(10);
		System.out.println(date2);
		
		
	}

}
