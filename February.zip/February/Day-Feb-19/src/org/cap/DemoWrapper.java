package org.cap;

import java.util.Date;

public class DemoWrapper {

	public static void main(String[] args) {
		int num=100;
		//Integer myNum=new Integer(num);
		
		//Auto boxing
		Integer myNum=num;
		
		

		
		
		//unboxing
		int count=myNum;
		
		
		
		String str="12";
		num=Integer.parseInt(str);
		num=Integer.valueOf(str);
		
		System.out.println("Number:" + num);
		
		
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.SIZE);
		System.out.println(Integer.BYTES);
		
		System.out.println(System.currentTimeMillis());
		
		long value=System.currentTimeMillis();
		Date myDate=new Date(value);
		System.out.println(myDate);

	}

}
