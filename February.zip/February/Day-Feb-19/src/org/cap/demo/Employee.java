package org.cap.demo;

import java.util.Date;

public class Employee {
	private int empId;
	private String kinId;
	private String firstname;
	private String lastName;
	private String address;
	private double salary;
	private Date doj;
	private Date dob;
	
	public Employee(){}
	
	//getter
	public int getEmpId(){
		return this.empId;
	}
	
	//setters
	public void setEmpId(int empId){
		this.empId=empId;
	}

	public String getKinId() {
		return kinId;
	}

	public void setKinId(String kinId) {
		this.kinId = kinId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", kinId=" + kinId + ", firstname=" + firstname + ", lastName=" + lastName
				+ ", address=" + address + ", salary=" + salary + ", doj=" + doj + ", dob=" + dob + "]";
	}
	
	
/*	
	@Override
	public String toString(){
		return "Employee[empId="+empId+"]";
	}
	
	
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	

}
