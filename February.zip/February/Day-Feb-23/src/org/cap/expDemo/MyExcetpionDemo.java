package org.cap.expDemo;

public class MyExcetpionDemo {

	public static void main(String[] args) {
		
		String str=null;
		
		try{
			if(str==null){
			throw new NullPointerException("Null is initialized!");
			}
		}catch(NullPointerException e){
			e.printStackTrace();
		}

	}

}
