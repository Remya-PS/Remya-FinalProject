package org.cap.expDemo;

import java.io.IOException;

public class WeeklyEmployee extends Employee{
	
	@Override
	public double findBonus() {
		String val=null;
		int val2=5;
		
		return Integer.parseInt(val)*val2;
	}

}
