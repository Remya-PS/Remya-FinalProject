package org.cap.demo;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		Employee emp=new Employee();
		
		System.out.println("Enter Employee Id:");
		int eid=sc.nextInt();
		emp.setEmpId(eid);
		
		System.out.println("Enter Employee Name:");
		String ename=sc.next();
		emp.setEmpName(ename);
		
		System.out.println("Enter Employee Salary:");
		double esalary=sc.nextDouble();
		
		
		try{
		if(Validation.isValidSalary(esalary))
			emp.setSalary(esalary);
		}catch(InvalidSalaryException ex){
			System.out.println(ex.getMessage());
		}
		
		
		System.out.println(emp);
		
		
		
		
		
	}

}
