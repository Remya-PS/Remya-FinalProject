package org.capgemini.assertiondemo;

public class AssertDemo {

	public static void main(String[] args) {
		
		int age=-1;
		
		//Assertion
		assert(age>0) : "Invalid Age! Should be greater than zero!";
		
		System.out.println("Age: " + age);
		

	}

}
