package org.capgemini.exception.demo;

public class Demo {

	public static void main(String[] args) {
		try{
		
		if(args.length==2){
		int num1=Integer.parseInt(args[0]);
		int num2=Integer.parseInt(args[2]);
			
		int ans;
		
			ans=num1/num2;
		
			System.out.println("Answer:" + ans);
		}
		}catch(NumberFormatException|ArithmeticException|ArrayIndexOutOfBoundsException ex){
			//System.out.println(ex.getMessage());
			ex.printStackTrace();
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println("Program Completed");
	}

}
