package org.capgemini;

public class TestClass {

	public static void main(String[] args) {
		String myStr="  Hello, we are learning Java!";
		
		String[] str=myStr.split("[ ,]");
		
		for(String s:str)
			System.out.println(s);
		
	}

}
