package org.capgemini;

@Author(authorName="viji")
public class Employee {
	
	@Author(authorName="viji",authorId=1001)
	private int empId;
	private String empName;
	public Employee(){}
	
	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	//@Author(authorName="viji",editDate="12-jan-2016")
	@Author(authorName="tom",editDate="22-feb-2016",authorId=2001)
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	

}
